<?php

return [
    'view_all'        => 'View All',
    'subscribe_watch' => 'Subskrybuj Watch | $0.00',
    'released'        => 'Wydany',
    'runtime'         => 'Czas działania',
    'genre'           => 'Gatunek',
    'stars'           => 'Gwiazdy',
    'director'        => 'Reżyser',
    'minutes'         => 'minut',
    'by'              => 'przez',
    'users'           => 'użytkowników',
    'download'        => 'Pobieranie',
    'season'          => 'Sezon',
    'watch'           => 'Zegarek',
    'episode'         => 'Odcinek',
    'movies'          => 'Filmy',
    'know_for'        => 'Znany z',
    'birthday'        => 'Urodziny',
    'place_of_birth'  => 'Miejsce urodzenia',
    'also_know_as'    => 'Znany również jako',
    'biography'       => 'Biografia',
    'sign_in'         => 'Zaloguj',
    'register'        => 'Zarejestrować',

    'watch_now'       => 'Patrz teraz',
];
