<?php

return [
    'movies'         => 'Filmy',
    'popular'        => 'Popularne',
    'now_playing'    => 'Obecnie w kinach',
    'top_rated'      => 'Najlepiej oceniane',
    'upcoming'       => 'Nadchodzące',
    'tv_shows'       => 'Seriale',
    'on_tv'          => 'W TV',
    'airing_today'   => 'Dzisiaj w tv',
    'genres'         => 'Gatunki',
    'popular_people' => 'Popularne Osoby',
    'search'         => 'Szukaj...',
];



