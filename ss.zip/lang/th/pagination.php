<?php

return [
    'previous' => '&laquo; ก่อนหน้า',
    'next'     => 'ถัดไป &raquo;',
];
