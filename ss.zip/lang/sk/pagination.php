<?php

return [
    'previous' => '&laquo; Predchádzajúca',
    'next'     => 'Nasledujúca &raquo;',
];
