<?php

return [
    'active_your_account_free' => '무료 계정을 활성화하십시오!',
    'you_must_create'          => '계속 시청하려면 계정을 만들어야합니다.',
    'continue_watch'           => '무료로 계속 시청하십시오. ➞',
    'quick_sign_up'            => '빠른 가입!',
    'take_less_then'           => '가입하는 데 1 분이 채되지 않아 무제한 영화 및 TV 타이틀을 즐길 수 있습니다.',
];
