<?php

return [
    'view_all'        => '모두보기',
    'subscribe_watch' => '시계 구독 신청 | $0.00',
    'released'        => '출시 됨',
    'runtime'         => '실행 시간',
    'genre'           => '유형',
    'stars'           => '별',
    'director'        => '감독',
    'minutes'         => '의사록',
    'by'              => '으로',
    'users'           => '사용자',
    'download'        => '다운로드',
    'season'          => '시즌',
    'watch'           => '손목 시계',
    'episode'         => '삽화',
    'movies'          => '영화 산업',
    'know_for'        => '알려진 대상',
    'birthday'        => '생일',
    'place_of_birth'  => '출생지',
    'also_know_as'    => '또한 ~으로 알려진',
    'biography'       => '전기',
    'sign_in'         => '로그인',
    'register'        => '레지스터',

    'watch_now'       => '지금보기',
];
