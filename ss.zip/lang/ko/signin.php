<?php

return [
    'sign_in'             => '로그인',
    'email'               => '이메일',
    'password'            => '암호',
    'well_never_share'    => '우리는 다른 사람과 귀하의 이메일을 절대 공유하지 않을 것입니다.',
    'forgot_password'     => '비밀번호를 잊으 셨나요?',
    'or'                  => '또는',
    'create_free_account' => '무료 계정 만들기',

    'enter_email'      => '이메일 입력',
    'reset_password'   => '암호를 재설정',
    'enter_your_email' => '이메일 주소를 입력하면 비밀번호 재설정 링크가 전송됩니다.',
    'back_to_sign_in'  => '로그인으로 돌아 가기',
    'loading'          => '기다려라....',
];
