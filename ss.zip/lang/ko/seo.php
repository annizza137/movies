<?php

return [
    'home_title'       => '무료 영화 및 TV 프로그램 스트림',
    'home_description' => '좋아하는 온라인 영화 및 시리즈를 무료로 찾아보고보십시오!',

    'movie_title' => '시계 :title 전체 영화 온라인 무료',
    'tv_title'    => ':title HD 무료 TV 쇼보기',
];
