<?php

return [
    'home_title'       => 'Transmitir Filmes e Programas de TV Gratuitos',
    'home_description' => 'Navegue e assista todos os seus filmes e séries online favoritos de graça!',

    'movie_title' => 'Assista :title Full Movie Online Grátis',
    'tv_title'    => 'Assista a Programas de TV Gratuitos :title HD',
];
