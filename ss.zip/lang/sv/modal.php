<?php

return [
    'active_your_account_free' => 'Aktivera ditt GRATIS konto!',
    'you_must_create'          => 'Du måste skapa ett konto för att fortsätta titta',
    'continue_watch'           => 'Fortsätt titta GRATIS ➞',
    'quick_sign_up'            => 'Snabb registrering!',
    'take_less_then'           => 'Det tar mindre än 1 minut att registrera dig, då kan du njuta av obegränsade filmer och TV-titlar.',
];
