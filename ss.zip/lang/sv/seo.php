<?php

return [
    'home_title'       => 'Strömma gratis filmer och TV-program',
    'home_description' => 'Bläddra och se alla dina favoritfilmer och serier online gratis!',

    'movie_title' => 'Se :title Full film online gratis',
    'tv_title'    => 'Se :title gratis TV-program HD',
];
