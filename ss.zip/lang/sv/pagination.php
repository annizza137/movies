<?php

return [
    'previous' => '&laquo; Föregående',
    'next'     => 'Nästa &raquo;',
];
