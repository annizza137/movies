<?php

return [
    'movies'         => 'Filmer',
    'popular'        => 'Populära',
    'now_playing'    => 'Visas nu',
    'top_rated'      => 'Toppbetyg',
    'upcoming'       => 'Kommande',
    'tv_shows'       => 'Tv-serier',
    'on_tv'          => 'På tv',
    'airing_today'   => 'Sänds i dag',
    'genres'         => 'Genrer',
    'popular_people' => 'Populära Personer',
    'search'         => 'Sök...',
];


