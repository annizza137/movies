<?php

return [
    'movies'         => 'Filmek',
    'popular'        => 'Népszerűek',
    'now_playing'    => 'Now Playing',
    'top_rated'      => 'Legjobbra értékeltek',
    'upcoming'       => 'Premierek',
    'tv_shows'       => 'Most játszottak',
    'on_tv'          => 'A TV-ben',
    'airing_today'   => 'Ma adásban',
    'genres'         => 'Műfajok',
    'popular_people' => 'Népszerűek',
    'search'         => 'Ψάξιμο...',
];

