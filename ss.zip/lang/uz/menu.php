<?php

return [
    'movies'         => 'Filmlar',
    'popular'        => 'Mashhur',
    'now_playing'    => 'Endi bajarilyapti',
    'top_rated'      => 'Top Reyting qoldirdi',
    'upcoming'       => 'Kutilayotgan',
    'tv_shows'       => 'TV ko\'rsatuvlar',
    'on_tv'          => 'Televizorda',
    'airing_today'   => 'Bugun efirda',
    'genres'         => 'Janrlar',
    'popular_people' => 'Ommabop Odamlar',
    'search'         => 'Qidirmoq...',
];

