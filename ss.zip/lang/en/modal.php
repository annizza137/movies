<?php

return [
    'active_your_account_free' => 'Activate your FREE Account!',
    'you_must_create'          => 'You must create an account to continue watching',
    'continue_watch'           => 'Continue to watch for FREE ➞',
    'quick_sign_up'            => 'Quick Sign Up!',
    'take_less_then'           => 'It takes less then 1 minute to Sign Up, then you can enjoy Unlimited Movies & TV titles.',
];
