<?php

return [
    'movies'         => 'Films',
    'popular'        => 'Populaire',
    'now_playing'    => 'Actuellement en Salles',
    'top_rated'      => 'Mieux Notés',
    'upcoming'       => 'Prochainement',
    'tv_shows'       => 'Télévision',
    'on_tv'          => 'Séries en cours de diffusion',
    'airing_today'   => 'Diffusées aujourd\'hui',
    'genres'         => 'Genres',
    'popular_people' => 'Artistes',
    'search'         => 'Chercher...',
];
