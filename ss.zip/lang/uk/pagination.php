<?php

return [
    'previous' => '&laquo; Назад',
    'next'     => 'Далі &raquo;',
];
