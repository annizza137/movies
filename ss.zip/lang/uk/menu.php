<?php

return [
    'movies'         => 'Фільми',
    'popular'        => 'Популярні',
    'now_playing'    => 'Зараз в ефірі',
    'top_rated'      => 'Рейтингові',
    'upcoming'       => 'Очікувані',
    'tv_shows'       => 'Серіали',
    'on_tv'          => 'Зараз по телевізору',
    'airing_today'   => 'Сьогодні в ефірі',
    'genres'         => 'Жанри',
    'popular_people' => 'Популярні',
    'search'         => 'Пошук...',
];


