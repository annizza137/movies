<?php

return [
    'movies'         => 'Movies',
    'popular'        => 'Populer',
    'now_playing'    => 'Now Playing',
    'top_rated'      => 'Top Rated',
    'upcoming'       => 'Upcoming',
    'tv_shows'       => 'Acara TV',
    'on_tv'          => 'On TV',
    'airing_today'   => 'Hari Ini',
    'genres'         => 'Genres',
    'popular_people' => 'Popular People',
    'search'         => 'Cari...',
];
