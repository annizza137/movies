<?php

return [
    'active_your_account_free' => 'Aktivujte si ZDARMA účet!',
    'you_must_create'          => 'Chcete-li pokračovat ve sledování, musíte si vytvořit účet',
    'continue_watch'           => 'Pokračujte ve sledování ZDARMA ➞',
    'quick_sign_up'            => 'Rychlé přihlášení!',
    'take_less_then'           => 'Registrace trvá méně než 1 minutu a poté si můžete vychutnat neomezený počet filmů a televizních titulů.',
];
