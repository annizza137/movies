<?php

return [
    'home_title'       => 'Filmy a televizní pořady zdarma',
    'home_description' => 'Procházejte a sledujte všechny své oblíbené online filmy a seriály zdarma!',

    'movie_title' => 'Sledujte :title Celý film online zdarma',
    'tv_title'    => 'Sledujte :title HD televizní pořady zdarma',
];
