<?php

return [
    'sign_in'             => 'Conectare',
    'email'               => 'E-mail',
    'password'            => 'Parola',
    'well_never_share'    => 'Nu vom împărtăși niciodată e-mailul cu altcineva.',
    'forgot_password'     => 'Ați uitat parola?',
    'or'                  => 'Sau',
    'create_free_account' => 'Creați cont gratuit',

    'enter_email'      => 'Introduceți Adresa de Email',
    'reset_password'   => 'Reseteaza parola',
    'enter_your_email' => 'Introduceți adresa de e-mail și vă vom trimite un link pentru a vă reseta parola.',
    'back_to_sign_in'  => 'Înapoi la Autentificare',
    'loading'          => 'Se incarca...',
];
