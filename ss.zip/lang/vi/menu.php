<?php

return [
    'movies'         => 'Phim',
    'popular'        => 'Phổ Biến',
    'now_playing'    => 'Hiện đang Chơi',
    'top_rated'      => 'Top Xếp Hạng',
    'upcoming'       => 'Sắp Tới',
    'tv_shows'       => 'Chương Trình Tivi',
    'on_tv'          => 'TV Phát',
    'airing_today'   => 'Sóng Ngày Hôm Nay',
    'genres'         => 'Thể Loại',
    'popular_people' => 'Những Người Nổi Tiếng',
    'search'         => 'Tìm Kiếm...',
];


