<?php

return [
    'home_title'       => 'Phát trực tuyến phim và chương trình truyền hình miễn phí',
    'home_description' => 'Duyệt và xem tất cả các bộ phim và bộ phim trực tuyến yêu thích của bạn miễn phí!',

    'movie_title' => 'Xem :title Phim trực tuyến miễn phí',
    'tv_title'    => 'Xem :title HD chương trình truyền hình miễn phí',
];
