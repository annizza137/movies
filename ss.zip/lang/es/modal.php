<?php

return [
    'active_your_account_free' => '¡Activa tu cuenta GRATIS!',
    'you_must_create'          => 'Debes crear una cuenta para seguir viendo',
    'continue_watch'           => 'Continúa mirando GRATIS ➞',
    'quick_sign_up'            => '¡Registro rápido!',
    'take_less_then'           => 'Registrarse toma menos de 1 minuto, luego puede disfrutar de películas y títulos de TV ilimitados.',
];
