<?php

return [
    'movies'         => 'Películas',
    'popular'        => 'Popular',
    'now_playing'    => 'En Cartelera Hoy',
    'top_rated'      => 'Mejor Valoradas',
    'upcoming'       => 'Próximamente',
    'tv_shows'       => 'Series',
    'on_tv'          => 'En Televisión',
    'airing_today'   => 'Se Emiten Hoy',
    'genres'         => 'Géneros',
    'popular_people' => 'Gente Popular',
    'search'         => 'Buscar...',
];


