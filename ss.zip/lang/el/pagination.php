<?php

return [
    'previous' => '&laquo; Προηγούμενη',
    'next'     => 'Επόμενη &raquo;',
];
