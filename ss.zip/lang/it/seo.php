<?php

return [
    'home_title' => 'Stream Free Movies & TV Shows',
    'home_description' => 'Browse and Watch all your favorite online movies & series for free!',

    'movie_title' => 'Guarda :title Film intero online gratuito',
    'tv_title' => 'Guarda :title HD TV Show',
];
