<?php

return [
    'previous' => '&lsaquo; Prec',
    'next' => 'Prossimo &rsaquo;'
];
