<?php

return [
    'previous' => '&laquo; Nazad',
    'next'     => 'Napred &raquo;',
];
