<?php

return [
    'movies'         => 'Фильмы',
    'popular'        => 'Популярные',
    'now_playing'    => 'Смотрят сейчас',
    'top_rated'      => 'Лучшие',
    'upcoming'       => 'Ожидаемые',
    'tv_shows'       => 'Сериалы',
    'on_tv'          => 'По телевидению',
    'airing_today'   => 'В эфире сегодня',
    'genres'         => 'Жанры',
    'popular_people' => 'Популярные люди',
    'search'         => 'Поиск...',
];


