- Untuk setting silahkan buka file config.php
- Untuk memasang iklan banner silahkan taruh kode di
    - /ads/above-player.blade.php => untuk banner diatas player
    - /ads/bottom-player.blade.php => untuk banner dibawah player
- Untuk pasang script di <head></head> taruh di /ads/head.blade.php
- Untuk pasang script histats di sebelum </body> taruh di /ads/foot.blade.php
- Untuk ganti logo replace /assets/img/logo.png
- Sitemap = domain.com/Sitemap
- untuk clear cache = domain.com/clear

##############################################

- For settings, please open the config.php file
- To place a banner ad, please put the code in
     - /ads/above-player.blade.php => for the banner above the player
     - /ads/bottom-player.blade.php => for the banner under the player
- To put the script in <head></head> put it in /ads/head.blade.php
- To put the hisstats script before </body> put it in /ads/foot.blade.php
- Untuk change logo replace /assets/img/logo.png
- Sitemap = domain.com/Sitemap
- To clear cache = domain.com/clear


/**
 * Movos = The php Script for Landing Page Movies and TV Series
 *
 * @author Mas Zee <facebook.com/mas.zee.9619>
 * @copyright 2022 Nanosia.com
 * @link https://Nanosia.com
 * @license Reselling is prohibited, or can only be used alone
 * @version 1.0.0
 */